<?php

namespace App\Controllers;

use AbieSoft\Http\Controller;
use AbieSoft\Models\Pembayaran;

class PembayaranController extends Controller
{

    public static function tab()
    {
        echo "Tab Pembayaran";
    }
}
