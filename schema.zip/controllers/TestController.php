<?php

namespace App\Controllers;

use AbieSoft\Http\Controller;
use AbieSoft\Models\Test;
use AbieSoft\Utilities\GetUri;

class TestController extends Controller
{

    public function testscript()
    {
        /*
            Test Script Anda Disini
        */
    }
}
