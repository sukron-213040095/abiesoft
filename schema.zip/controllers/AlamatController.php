<?php

namespace App\Controllers;

use AbieSoft\Http\Controller;

class AlamatController extends Controller
{

    public static function tab()
    {
        echo "Tab Alamat";
    }
}
