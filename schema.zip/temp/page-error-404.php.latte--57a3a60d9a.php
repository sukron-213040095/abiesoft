<?php

use Latte\Runtime as LR;

/** source: D:\app\test\abiesoft\app\Http/../../templates/page/error/404.php.latte */
final class Template57a3a60d9a extends Latte\Runtime\Template
{

	public function main(array $ʟ_args): void
	{
		echo 'error';
	}
}
