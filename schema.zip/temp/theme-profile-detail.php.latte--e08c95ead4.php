<?php

use Latte\Runtime as LR;

/** source: D:\app\test\abiesoft\app\Http/../../templates/page/../theme/profile/detail.php.latte */
final class Templatee08c95ead4 extends Latte\Runtime\Template
{

	public function main(array $ʟ_args): void
	{
		echo 'detail';
	}
}
