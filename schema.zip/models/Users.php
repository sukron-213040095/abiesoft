<?php

namespace App\Models;

use AbieSoft\Data\Collection;

class Users
{
    use Collection;
}
