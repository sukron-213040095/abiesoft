function hidePopUp(){
    document.getElementById('popup').innerHTML = "";
}


